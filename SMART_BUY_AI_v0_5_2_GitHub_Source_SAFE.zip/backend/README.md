# SMART BUY AI backend (0.4.0)

FastAPI + SQLAlchemy backend for normalized products, retail/wholesale offers and separate product/seller reviews.

## Run locally

```bash
cd backend
python -m venv .venv
# activate the environment, then:
pip install -r requirements.txt
cp .env.example .env
uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
```

Open `/docs` for interactive API documentation and `/health` for health status.

## Endpoints
- `GET /health`
- `GET /v1/sources` — connector readiness; marketplace adapters remain disabled until access is approved
- `GET /v1/discovery/search?q=...` — automatically refreshes configured feeds (at most once per 30 minutes) and searches the unified catalogue; public read endpoint
- `POST /v1/discovery/refresh` — force refresh configured feeds (operator endpoint)
- `GET /v1/products?q=...`
- `POST /v1/products`
- `POST /v1/import/offers` — import a permitted partner/merchant/affiliate feed after mapping it to the normalized JSON schema
- `GET /v1/products/{id}/offers`
- `GET /v1/products/{id}/comparison?mode=retail|wholesale` — ranks by price plus shipping; retail and wholesale are kept separate
- `GET /v1/products/{id}/reviews?review_type=product|seller`

## Automatic search without marketplace API keys

The Android app can send a search to `/v1/discovery/search` after the server URL is saved in Profile. The server refreshes explicitly configured public XML/YML or RSS/Atom feeds on the first search and then no more often than every 30 minutes. Configure `PUBLIC_FEED_URLS` in the server environment:

```env
PUBLIC_FEED_URLS=shop_a=https://shop-a.example/catalog.yml;shop_b=https://shop-b.example/feed.xml
```

Only HTTPS feed URLs are accepted. Private/local hosts, redirects, oversized feeds, and HTML pages are rejected. The importer reads structured feed fields only; it does not crawl marketplace search pages or bypass login, CAPTCHA, robots restrictions, rate limits, or terms. No feeds are preconfigured in this project, so the automatic-search pipeline returns no live products until a store/partner supplies a permitted feed URL. A feed can be free and require no API key, but permission to use it is still required.

## Feed import without marketplace credentials
You do not need marketplace API credentials to develop the importer. You do need permission to use the data you import. The example payload is in `examples/partner_feed_example.json`. A future CSV converter can map a partner's approved product feed into this JSON format. The example is synthetic and must not be displayed as a real offer.

## Source access notes
- Ozon Statistics API for independent analytics services is a separately approved commercial product; request access from Ozon.
- Yandex Market Partner API is primarily seller-facing; its scope depends on the seller account and permissions.
- Wildberries seller API keys are tied to seller-account permissions, not a general public consumer catalogue.
- Other retailer/marketplace integrations must be confirmed individually. No connector scrapes restricted pages, bypasses login, CAPTCHA, rate limits or terms.

## Security before production
- Set a long random `API_KEY`; protect all `/v1/*` routes (the source status endpoint is public).
- Use HTTPS and keep secrets in server environment/secret manager, never in Android resources or APK.
- Replace SQLite with managed PostgreSQL for production.
- Add user auth, rate limits, audit logs, retention/deletion controls and monitoring.
- Add consent, privacy policy and legal review before collecting personal data.


### v0.7.0 product intelligence endpoints
- `GET /v1/products/{id}/price-history?days=90` — recorded offer price snapshots.
- `GET /v1/products/{id}/review-summary` — separate product and seller review aggregates.
- `POST /v1/import/reviews` — authorized review import with source URL and review type.
- `GET /v1/products/{id}/recommendations` — current best in-stock retail offer with evidence-based reasons; not a future-price prediction.
Price history starts when feeds are imported and only records new/changed offers; it cannot reconstruct earlier prices.
