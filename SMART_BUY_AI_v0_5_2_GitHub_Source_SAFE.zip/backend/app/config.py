from pydantic_settings import BaseSettings, SettingsConfigDict

class Settings(BaseSettings):
    app_env: str = "development"
    database_url: str = "sqlite:///./smartbuy.db"
    api_key: str = ""
    public_feed_urls: str = ""  # source=https://...;source2=https://...
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

settings = Settings()
