from dataclasses import dataclass
from typing import Protocol

@dataclass
class AdapterStatus:
    source: str
    status: str
    mode: str
    note: str

class MarketplaceAdapter(Protocol):
    source: str
    async def search(self, query: str) -> list[dict]: ...
    async def status(self) -> AdapterStatus: ...

class NotConfiguredAdapter:
    """Safe placeholder: never scrapes or fabricates live data."""
    def __init__(self, source: str, note: str):
        self.source, self.note = source, note
    async def search(self, query: str) -> list[dict]:
        return []
    async def status(self) -> AdapterStatus:
        return AdapterStatus(self.source, "not_configured", "disabled", self.note)
