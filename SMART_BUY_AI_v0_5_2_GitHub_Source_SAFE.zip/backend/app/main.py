from fastapi import Depends, FastAPI, Header, HTTPException, Query
from sqlalchemy import or_, select
from sqlalchemy.orm import Session
import time
from .config import settings
from .db import Base, engine, get_db
from .models import Offer, Product, Review, PriceSnapshot
from .schemas import FeedImportIn, OfferOut, ProductCreate, ProductOut, ReviewOut, ReviewImportIn
from .adapters.registry import ADAPTERS
from .discovery import configured_feeds, fetch_feed
from .matching import strong_match, candidate_score, normalize as _normalize

Base.metadata.create_all(bind=engine)
# Lightweight additive migration for existing SQLite installs.
if engine.dialect.name == "sqlite":
    from sqlalchemy import inspect
    existing = {c["name"] for c in inspect(engine).get_columns("products")}
    for column, sql_type in (("clothing_type", "VARCHAR(120)"), ("size", "VARCHAR(40)"),
                             ("color", "VARCHAR(80)"), ("material", "VARCHAR(160)"),
                             ("gender", "VARCHAR(40)"), ("season", "VARCHAR(60)")):
        if column not in existing:
            with engine.begin() as conn:
                conn.exec_driver_sql(f"ALTER TABLE products ADD COLUMN {column} {sql_type}")
app = FastAPI(title="SMART BUY AI API", version="0.7.0", description="Backend for automatic discovery from permitted public merchant feeds")
_last_feed_refresh = 0.0

async def _refresh_configured_feeds(db: Session, force: bool = False):
    global _last_feed_refresh
    now = time.monotonic()
    feeds = configured_feeds(settings.public_feed_urls)
    if not feeds:
        return {"configured": 0, "imported": 0, "results": [], "note": "Открытые фиды не настроены"}
    if not force and now - _last_feed_refresh < 1800:
        return {"configured": len(feeds), "imported": 0, "results": [], "note": "Используем недавно обновлённый каталог"}
    results, total = [], 0
    for source, url in feeds:
        try:
            rows = await fetch_feed(source, url)
            if not rows:
                results.append({"source": source, "status": "empty", "imported": 0})
                continue
            result = import_partner_feed(FeedImportIn(source=source, offers=rows[:1000]), db)
            count = result["created_offers"] + result["updated_offers"]
            total += count
            results.append({"source": source, "status": "ok", "imported": len(rows), "created": result["created_offers"], "updated": result["updated_offers"]})
        except Exception as exc:
            results.append({"source": source, "status": "error", "imported": 0, "reason": str(exc)[:240]})
    _last_feed_refresh = now
    return {"configured": len(feeds), "imported": total, "results": results}


@app.middleware("http")
async def optional_api_key(request, call_next):
    protected = request.url.path.startswith("/v1/") and request.url.path not in {"/v1/sources", "/v1/discovery/search"}
    if protected and settings.api_key:
        if request.headers.get("x-api-key") != settings.api_key:
            raise HTTPException(status_code=401, detail="Invalid API key")
    return await call_next(request)

@app.get("/health")
def health():
    return {"ok": True, "service": "smart-buy-ai-api", "version": "0.7.0"}

@app.get("/v1/sources")
async def sources():
    result = []
    for adapter in ADAPTERS.values():
        s = await adapter.status()
        result.append({"source": s.source, "status": s.status, "mode": s.mode, "note": s.note})
    feeds = configured_feeds(settings.public_feed_urls)
    if feeds:
        result.append({"source": "merchant_feeds", "status": "configured", "mode": "public_feed", "note": f"Настроено открытых фидов: {len(feeds)}"})
    return {"items": result, "live_data_enabled": bool(feeds), "automatic_discovery": "configured_feeds_only"}

@app.get("/v1/products", response_model=list[ProductOut])
def search_products(q: str = Query(min_length=1, max_length=160), db: Session = Depends(get_db)):
    stmt = select(Product).where(or_(Product.title.ilike(f"%{q}%"), Product.brand.ilike(f"%{q}%"), Product.model.ilike(f"%{q}%"), Product.gtin == q)).limit(50)
    return list(db.scalars(stmt))

@app.get("/v1/products/{product_id}", response_model=ProductOut)
def get_product(product_id: int, db: Session = Depends(get_db)):
    product = db.get(Product, product_id)
    if product is None:
        raise HTTPException(status_code=404, detail="Product not found")
    return product


@app.post("/v1/products", response_model=ProductOut, status_code=201)
def create_product(payload: ProductCreate, db: Session = Depends(get_db)):
    item = Product(**payload.model_dump())
    db.add(item); db.commit(); db.refresh(item)
    return item

@app.get("/v1/products/{product_id}/offers", response_model=list[OfferOut])
def product_offers(product_id: int, db: Session = Depends(get_db)):
    rows = list(db.scalars(select(Offer).where(Offer.product_id == product_id).order_by(Offer.price)))
    # Never compare wholesale unit prices with retail offers in one ranked list.
    return rows

@app.get("/v1/products/{product_id}/reviews", response_model=list[ReviewOut])
def product_reviews(product_id: int, review_type: str | None = Query(default=None, pattern="^(product|seller)$"), db: Session = Depends(get_db)):
    stmt = select(Review).where(Review.product_id == product_id)
    if review_type: stmt = stmt.where(Review.review_type == review_type)
    return list(db.scalars(stmt.order_by(Review.published_at.desc()).limit(100)))


@app.get("/v1/products/{product_id}/price-history")
def product_price_history(product_id: int, days: int = Query(default=90, ge=1, le=365), db: Session = Depends(get_db)):
    if db.get(Product, product_id) is None:
        raise HTTPException(status_code=404, detail="Product not found")
    from datetime import datetime, timedelta, timezone
    since = datetime.now(timezone.utc) - timedelta(days=days)
    rows = list(db.scalars(select(PriceSnapshot).where(PriceSnapshot.product_id == product_id, PriceSnapshot.observed_at >= since).order_by(PriceSnapshot.observed_at.asc()).limit(1000)))
    return {"product_id": product_id, "days": days, "items": [{"source": r.source, "price": r.price, "shipping": r.shipping, "total_price": r.price + (r.shipping or 0), "currency": r.currency, "observed_at": r.observed_at} for r in rows], "note": "История строится только с момента поступления данных из подключённых фидов; прошлые цены задним числом не восстанавливаются."}

@app.get("/v1/products/{product_id}/recommendations")
def product_recommendations(product_id: int, db: Session = Depends(get_db)):
    product = db.get(Product, product_id)
    if product is None:
        raise HTTPException(status_code=404, detail="Product not found")
    offers = list(db.scalars(select(Offer).where(Offer.product_id == product_id, Offer.is_wholesale == False)))
    available = [o for o in offers if o.in_stock is not False]
    if not available:
        return {"product_id": product_id, "verdict": "insufficient_data", "score": None, "reasons": ["Нет актуальных розничных предложений в подключённых фидах."], "best_offer": None}
    best = min(available, key=lambda o: o.price + (o.shipping or 0))
    history = list(db.scalars(select(PriceSnapshot).where(PriceSnapshot.product_id == product_id).order_by(PriceSnapshot.observed_at.desc()).limit(30)))
    reasons = [f"Самая низкая найденная итоговая цена: {best.price + (best.shipping or 0):.2f} {best.currency} в источнике {best.source}."]
    if len(history) >= 2:
        old = history[-1].price + (history[-1].shipping or 0); new = history[0].price + (history[0].shipping or 0)
        reasons.append("Цена снизилась относительно первой сохранённой точки." if new < old else "Цена не ниже первой сохранённой точки.")
    else:
        reasons.append("Истории пока недостаточно для оценки выгодного момента покупки.")
    return {"product_id": product_id, "verdict": "best_current_offer", "score": None, "reasons": reasons, "best_offer": {"source": best.source, "price": best.price, "shipping": best.shipping, "total_price": best.price + (best.shipping or 0), "currency": best.currency, "url": best.url}, "note": "Рекомендация основана на данных фидов, а не на прогнозе будущей цены."}

@app.post("/v1/import/reviews")
def import_reviews(payload: ReviewImportIn, db: Session = Depends(get_db)):
    created = updated = 0
    for row in payload.reviews:
        if db.get(Product, row.product_id) is None:
            raise HTTPException(status_code=404, detail=f"Product {row.product_id} not found")
        if row.source_url and not row.source_url.startswith(("https://", "http://")):
            raise HTTPException(status_code=422, detail="Review URL must use http or https")
        review = db.scalar(select(Review).where(Review.source == row.source, Review.external_id == row.external_id))
        values = row.model_dump()
        if review is None:
            db.add(Review(**values)); created += 1
        else:
            for key, value in values.items(): setattr(review, key, value)
            updated += 1
    db.commit()
    return {"received": len(payload.reviews), "created": created, "updated": updated, "note": "Импортируйте только отзывы, которые разрешено хранить и показывать; сохраняйте ссылку на первоисточник."}

@app.get("/v1/products/{product_id}/review-summary")
def product_review_summary(product_id: int, db: Session = Depends(get_db)):
    if db.get(Product, product_id) is None:
        raise HTTPException(status_code=404, detail="Product not found")
    result = {}
    for kind in ("product", "seller"):
        rows = list(db.scalars(select(Review).where(Review.product_id == product_id, Review.review_type == kind)))
        ratings = [r.rating for r in rows if r.rating is not None]
        result[kind] = {"count": len(rows), "average_rating": round(sum(ratings)/len(ratings), 2) if ratings else None}
    return {"product_id": product_id, "summary": result, "note": "Оценки рассчитываются только по импортированным разрешённым отзывам."}


@app.get("/v1/discovery/search")
async def discovery_search(q: str = Query(min_length=2, max_length=160),
                           brand: str | None = None, size: str | None = None,
                           color: str | None = None, material: str | None = None,
                           gender: str | None = None, season: str | None = None,
                           clothing_type: str | None = None,
                           db: Session = Depends(get_db)):
    """Search permitted feeds and apply optional apparel attributes."""
    refresh = await _refresh_configured_feeds(db)
    term = f"%{q.strip()}%"
    stmt = select(Product).where(or_(Product.title.ilike(term), Product.brand.ilike(term), Product.model.ilike(term), Product.gtin == q.strip()))
    for field, value in (("brand", brand), ("size", size), ("color", color), ("material", material), ("gender", gender), ("season", season), ("clothing_type", clothing_type)):
        if value and value.strip():
            stmt = stmt.where(getattr(Product, field).ilike(f"%{value.strip()}%"))
    products = list(db.scalars(stmt.limit(40)))
    items = []
    for product in products:
        offers = list(db.scalars(select(Offer).where(Offer.product_id == product.id).limit(50)))
        # Rank retail and wholesale independently; include delivery in the displayed total.
        offers.sort(key=lambda o: (o.is_wholesale, o.price + (o.shipping or 0)))
        serialized = []
        now = time.time()
        for offer in offers[:30]:
            item = OfferOut.model_validate(offer).model_dump(mode="json")
            item["total_price"] = offer.price + (offer.shipping or 0)
            observed = offer.observed_at
            item["age_seconds"] = max(0, int(now - observed.timestamp())) if observed else None
            item["freshness"] = ("fresh" if item["age_seconds"] is not None and item["age_seconds"] <= 86400
                                  else "stale" if item["age_seconds"] is not None else "unknown")
            serialized.append(item)
        items.append({"product": ProductOut.model_validate(product).model_dump(),
                      "offers": serialized})
    return {"query": q, "items": items, "results": len(items), "feed_refresh": refresh,
            "filters": {"brand": brand, "size": size, "color": color, "material": material, "gender": gender, "season": season, "clothing_type": clothing_type},
            "data_note": "Только предложения из разрешённых импортированных фидов; фильтры применяются к характеристикам, переданным источником."}

@app.post("/v1/discovery/refresh")
async def discovery_refresh(db: Session = Depends(get_db)):
    """Force refresh of only the public feeds explicitly configured by the operator."""
    return await _refresh_configured_feeds(db, force=True)


@app.get("/v1/matching/candidates")
def matching_candidates(q: str = Query(min_length=2, max_length=160), brand: str | None = None,
                        model: str | None = None, gtin: str | None = None,
                        db: Session = Depends(get_db)):
    """Return cross-store identity candidates; fuzzy candidates require user confirmation."""
    term = f"%{q.strip()}%"
    stmt = select(Product).where(or_(Product.title.ilike(term), Product.brand.ilike(term),
                                     Product.model.ilike(term), Product.gtin == q.strip())).limit(100)
    rows = list(db.scalars(stmt))
    ranked = []
    for product in rows:
        score, reason = candidate_score(product, title=q, brand=brand, model=model, gtin=gtin)
        if score >= 0.62:
            offers = list(db.scalars(select(Offer).where(Offer.product_id == product.id).limit(50)))
            retail = sorted((o for o in offers if not o.is_wholesale), key=lambda o: o.price + (o.shipping or 0))
            wholesale = sorted((o for o in offers if o.is_wholesale), key=lambda o: o.price + (o.shipping or 0))
            ranked.append({"product": ProductOut.model_validate(product).model_dump(),
                           "match_score": score, "match_reason": reason,
                           "requires_confirmation": score < 0.985,
                           "retail_offers": [{"source": o.source, "price": o.price,
                               "shipping": o.shipping, "total_price": o.price + (o.shipping or 0),
                               "currency": o.currency, "in_stock": o.in_stock, "url": o.url}
                               for o in retail[:10]],
                           "wholesale_offers": [{"source": o.source, "price": o.price,
                               "shipping": o.shipping, "total_price": o.price + (o.shipping or 0),
                               "currency": o.currency, "min_order_quantity": o.min_order_quantity, "url": o.url}
                               for o in wholesale[:10]]})
    ranked.sort(key=lambda x: x["match_score"], reverse=True)
    return {"query": q, "candidates": ranked[:30],
            "note": "Нечёткое сходство не объединяет товары автоматически. Сверяйте модель, размер, цвет и комплектацию."}


@app.post("/v1/import/offers")
def import_partner_feed(payload: FeedImportIn, db: Session = Depends(get_db)):
    """Import offers from a permitted partner CSV/feed after mapping it to this schema.

    This endpoint does not fetch marketplace pages or bypass access controls.
    The caller must have rights to supply the feed data.
    """
    allowed_sources = set(ADAPTERS) | {"partner_feed", "merchant_feed", "affiliate_feed"} | {name for name, _ in configured_feeds(settings.public_feed_urls)}
    if payload.source not in allowed_sources:
        raise HTTPException(status_code=400, detail="Unknown source. Register and approve it first.")

    created_products = 0
    created_offers = 0
    updated_offers = 0
    for row in payload.offers:
        if row.url and not row.url.startswith(("https://", "http://")):
            raise HTTPException(status_code=422, detail="Offer URL must use http or https")
        product = None
        # Strong identity only: barcode, then exact normalized brand+model,
        # then exact normalized title/brand. Similar titles are never auto-merged.
        if row.gtin:
            digits = "".join(ch for ch in row.gtin if ch.isdigit())
            if len(digits) in (8, 12, 13, 14):
                product = db.scalar(select(Product).where(Product.gtin == row.gtin))
                if product is None:
                    for candidate in db.scalars(select(Product).where(Product.gtin.is_not(None)).limit(500)):
                        matched, _ = strong_match(candidate, gtin=row.gtin, brand=row.brand, model=row.model, title=row.title)
                        if matched:
                            product = candidate
                            break
        if product is None and row.brand and row.model:
            candidates = list(db.scalars(select(Product).where(Product.brand.ilike(row.brand)).limit(100)))
            product = next((p for p in candidates if strong_match(p, gtin=None, brand=row.brand, model=row.model, title=row.title)[0]), None)
        if product is None:
            candidates = list(db.scalars(select(Product).where(Product.title.ilike(f"%{row.title[:80]}%")).limit(100)))
            product = next((p for p in candidates if strong_match(p, gtin=None, brand=row.brand, model=None, title=row.title)[0]), None)
        if product is None:
            product = Product(title=row.title, brand=row.brand, model=row.model, gtin=row.gtin, category=row.category)
            db.add(product); db.flush(); created_products += 1

        offer = db.scalar(select(Offer).where(Offer.source == payload.source, Offer.external_id == row.external_id))
        values = dict(product_id=product.id, source=payload.source, external_id=row.external_id, seller=row.seller, price=row.price, currency=row.currency.upper(), shipping=row.shipping, in_stock=row.in_stock, url=row.url, is_wholesale=row.is_wholesale, min_order_quantity=row.min_order_quantity)
        for attr in ("clothing_type", "size", "color", "material", "gender", "season"):
            value = getattr(row, attr)
            if value and not getattr(product, attr):
                setattr(product, attr, value)
        if offer is None:
            offer = Offer(**values); db.add(offer); db.flush(); created_offers += 1
            db.add(PriceSnapshot(offer_id=offer.id, product_id=product.id, source=payload.source, price=row.price, shipping=row.shipping, currency=row.currency.upper()))
        else:
            changed = (offer.price != row.price or offer.shipping != row.shipping or offer.currency != row.currency.upper())
            for key, value in values.items():
                setattr(offer, key, value)
            if changed:
                db.add(PriceSnapshot(offer_id=offer.id, product_id=product.id, source=payload.source, price=row.price, shipping=row.shipping, currency=row.currency.upper()))
            updated_offers += 1
    db.commit()
    return {"source": payload.source, "received": len(payload.offers), "created_products": created_products, "created_offers": created_offers, "updated_offers": updated_offers, "note": "Imported feed data; source permission and freshness must be verified by the operator."}

@app.get("/v1/products/{product_id}/comparison")
def compare_offers(product_id: int, mode: str = Query(default="retail", pattern="^(retail|wholesale)$"), db: Session = Depends(get_db)):
    if db.get(Product, product_id) is None:
        raise HTTPException(status_code=404, detail="Product not found")
    rows = list(db.scalars(select(Offer).where(Offer.product_id == product_id, Offer.is_wholesale == (mode == "wholesale"))))
    def total(row):
        return row.price + (row.shipping or 0)
    rows.sort(key=total)
    return {"product_id": product_id, "mode": mode, "items": [{"id": r.id, "source": r.source, "seller": r.seller, "price": r.price, "shipping": r.shipping, "total_price": total(r), "currency": r.currency, "in_stock": r.in_stock, "url": r.url, "min_order_quantity": r.min_order_quantity, "observed_at": r.observed_at} for r in rows]}
