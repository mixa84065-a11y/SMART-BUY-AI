"""Conservative product identity matching for cross-store comparisons.

Only strong identifiers are used for automatic grouping. Fuzzy title similarity
is exposed as a reviewable candidate and never silently merges catalog records.
"""
from __future__ import annotations
import re
from difflib import SequenceMatcher

_TOKEN_RE = re.compile(r"[^0-9a-zа-яё]+", re.IGNORECASE)


def normalize(value: str | None) -> str:
    return " ".join(_TOKEN_RE.sub(" ", (value or "").casefold().replace("ё", "е")).split())


def identity_key(*, gtin: str | None, brand: str | None, model: str | None, title: str | None) -> tuple[str, ...] | None:
    code = re.sub(r"\D", "", gtin or "")
    if len(code) in (8, 12, 13, 14):
        return ("gtin", code)
    b, m, t = normalize(brand), normalize(model), normalize(title)
    if b and m:
        return ("brand_model", b, m)
    if t:
        return ("title", b, t)
    return None


def strong_match(a, *, gtin: str | None, brand: str | None, model: str | None, title: str | None) -> tuple[bool, str | None]:
    incoming = identity_key(gtin=gtin, brand=brand, model=model, title=title)
    existing = identity_key(gtin=getattr(a, "gtin", None), brand=getattr(a, "brand", None),
                            model=getattr(a, "model", None), title=getattr(a, "title", None))
    if incoming and incoming == existing:
        return True, incoming[0]
    return False, None


def similarity(a_title: str, b_title: str) -> float:
    a, b = normalize(a_title), normalize(b_title)
    if not a or not b:
        return 0.0
    seq = SequenceMatcher(None, a, b).ratio()
    at, bt = set(a.split()), set(b.split())
    overlap = len(at & bt) / max(1, len(at | bt))
    return round(max(seq, overlap), 4)


def candidate_score(product, *, title: str, brand: str | None, model: str | None, gtin: str | None) -> tuple[float, str]:
    if gtin and getattr(product, "gtin", None):
        digits_a, digits_b = re.sub(r"\D", "", gtin), re.sub(r"\D", "", product.gtin)
        if digits_a == digits_b and len(digits_a) in (8, 12, 13, 14):
            return 1.0, "Совпадает штрихкод"
    b1, b2 = normalize(brand), normalize(getattr(product, "brand", None))
    m1, m2 = normalize(model), normalize(getattr(product, "model", None))
    if b1 and b2 and m1 and m2 and b1 == b2 and m1 == m2:
        return 0.99, "Совпадают бренд и модель"
    score = similarity(title, getattr(product, "title", ""))
    if b1 and b2:
        score = min(1.0, score + (0.08 if b1 == b2 else -0.15))
    elif b1 != b2 and (b1 or b2):
        score = max(0.0, score - 0.12)
    if m1 and m2:
        score = min(1.0, score + (0.08 if m1 == m2 else -0.15))
    return round(max(0.0, score), 4), "Похожее название; нужна проверка"
