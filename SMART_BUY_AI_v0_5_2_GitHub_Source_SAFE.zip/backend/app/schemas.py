from datetime import datetime
from pydantic import BaseModel, ConfigDict, Field

class ProductOut(BaseModel):
    id: int
    title: str
    brand: str | None = None
    model: str | None = None
    gtin: str | None = None
    category: str | None = None
    clothing_type: str | None = None
    size: str | None = None
    color: str | None = None
    material: str | None = None
    gender: str | None = None
    season: str | None = None
    model_config = ConfigDict(from_attributes=True)

class OfferOut(BaseModel):
    id: int
    source: str
    seller: str | None
    price: float
    currency: str
    shipping: float | None
    in_stock: bool | None
    url: str | None
    is_wholesale: bool
    min_order_quantity: int | None
    observed_at: datetime
    model_config = ConfigDict(from_attributes=True)

class ReviewOut(BaseModel):
    id: int
    source: str
    review_type: str
    author: str | None
    rating: float | None
    body: str | None
    source_url: str | None
    published_at: datetime | None
    model_config = ConfigDict(from_attributes=True)

class SourceStatus(BaseModel):
    source: str
    status: str
    mode: str
    note: str

class ProductCreate(BaseModel):
    title: str = Field(min_length=2, max_length=500)
    brand: str | None = None
    model: str | None = None
    gtin: str | None = None
    category: str | None = None


class FeedOfferIn(BaseModel):
    external_id: str = Field(min_length=1, max_length=180)
    title: str = Field(min_length=2, max_length=500)
    brand: str | None = Field(default=None, max_length=160)
    model: str | None = Field(default=None, max_length=160)
    gtin: str | None = Field(default=None, max_length=32)
    category: str | None = Field(default=None, max_length=120)
    clothing_type: str | None = Field(default=None, max_length=120)
    size: str | None = Field(default=None, max_length=40)
    color: str | None = Field(default=None, max_length=80)
    material: str | None = Field(default=None, max_length=160)
    gender: str | None = Field(default=None, max_length=40)
    season: str | None = Field(default=None, max_length=60)
    seller: str | None = Field(default=None, max_length=250)
    price: float = Field(ge=0)
    currency: str = Field(default="RUB", min_length=3, max_length=8)
    shipping: float | None = Field(default=None, ge=0)
    in_stock: bool | None = None
    url: str | None = Field(default=None, max_length=2000)
    is_wholesale: bool = False
    min_order_quantity: int | None = Field(default=None, ge=1)

class FeedImportIn(BaseModel):
    source: str = Field(min_length=2, max_length=80)
    offers: list[FeedOfferIn] = Field(min_length=1, max_length=1000)


class ReviewIn(BaseModel):
    external_id: str = Field(min_length=1, max_length=180)
    product_id: int
    source: str = Field(min_length=2, max_length=80)
    review_type: str = Field(pattern="^(product|seller)$")
    author: str | None = None
    rating: float | None = Field(default=None, ge=0, le=5)
    body: str | None = Field(default=None, max_length=10000)
    source_url: str | None = Field(default=None, max_length=2000)
    published_at: datetime | None = None

class ReviewImportIn(BaseModel):
    reviews: list[ReviewIn] = Field(min_length=1, max_length=1000)
