"""Import explicitly configured, permitted public merchant feeds.

This module accepts structured XML/YML/RSS/Atom feeds only. It deliberately does
not crawl HTML pages, bypass access controls, or follow redirects.
"""
from __future__ import annotations
import ipaddress
import socket
import xml.etree.ElementTree as ET
from urllib.parse import urlparse
import httpx

USER_AGENT = "SMART-BUY-AI-FeedReader/0.2 (public-feed-import)"
MAX_FEED_BYTES = 8 * 1024 * 1024


def configured_feeds(raw: str) -> list[tuple[str, str]]:
    feeds: list[tuple[str, str]] = []
    for item in (raw or "").split(";"):
        if "=" not in item:
            continue
        source, url = item.split("=", 1)
        source, url = source.strip().lower(), url.strip()
        if source and url:
            feeds.append((source, url))
    return feeds


def _validate_feed_url(url: str) -> None:
    parsed = urlparse(url)
    if parsed.scheme != "https" or not parsed.hostname or parsed.username or parsed.password:
        raise ValueError("Feed URL must be a public HTTPS URL")
    if parsed.port not in (None, 443):
        raise ValueError("Only standard HTTPS port 443 is allowed")
    try:
        addresses = socket.getaddrinfo(parsed.hostname, 443, type=socket.SOCK_STREAM)
    except OSError as exc:
        raise ValueError("Feed host cannot be resolved") from exc
    if not addresses:
        raise ValueError("Feed host has no public address")
    for item in addresses:
        ip = ipaddress.ip_address(item[4][0])
        if not ip.is_global:
            raise ValueError("Private or local feed hosts are not allowed")


def _local(tag: str) -> str:
    return tag.rsplit("}", 1)[-1].lower()


def _first(node: ET.Element, *names: str) -> ET.Element | None:
    wanted = {n.lower() for n in names}
    for child in node.iter():
        if _local(child.tag) in wanted:
            return child
    return None


def _text(node: ET.Element, *names: str) -> str | None:
    found = _first(node, *names)
    if found is not None and found.text and found.text.strip():
        return found.text.strip()
    return None


def _link(node: ET.Element) -> str | None:
    found = _first(node, "url", "link")
    if found is None:
        return None
    # Atom uses <link href="..."/>; RSS usually uses <link>URL</link>.
    return (found.attrib.get("href") or (found.text or "")).strip() or None


def _param(offer: ET.Element, *names: str) -> str | None:
    wanted = {n.casefold() for n in names}
    for node in offer.iter():
        if _local(node.tag) != "param":
            continue
        label = (node.attrib.get("name") or "").strip().casefold()
        if label in wanted and node.text and node.text.strip():
            return node.text.strip()
    return None


def _price(value: str | None) -> float | None:
    if not value:
        return None
    try:
        result = float(value.replace("\u00a0", "").replace(" ", "").replace(",", "."))
        return result if result >= 0 else None
    except ValueError:
        return None


def parse_yml_or_rss(xml_text: str, source: str) -> list[dict]:
    # Reject DTD/entity declarations rather than processing potentially hostile XML.
    upper = xml_text[:200_000].upper()
    if "<!DOCTYPE" in upper or "<!ENTITY" in upper:
        raise ValueError("DTD/entity declarations are not accepted")
    root = ET.fromstring(xml_text)
    rows: list[dict] = []

    # Namespace-independent YML offers.
    currencies: dict[str, str] = {}
    for currency in root.iter():
        if _local(currency.tag) == "currency":
            code = currency.attrib.get("id")
            rate = currency.attrib.get("rate")
            if code:
                currencies[code] = "RUB" if rate in (None, "1") else code
    for offer in (n for n in root.iter() if _local(n.tag) == "offer"):
        title = _text(offer, "name", "model", "title")
        price = _price(_text(offer, "price"))
        if not title or price is None:
            continue
        currency_node = _first(offer, "currencyId")
        currency = (currency_node.text.strip() if currency_node is not None and currency_node.text else "RUB")
        available = offer.attrib.get("available", "true").strip().lower()
        rows.append({
            "external_id": offer.attrib.get("id") or _link(offer) or title[:170],
            "title": title,
            "brand": _text(offer, "vendor", "brand"),
            "model": _text(offer, "vendorCode", "model"),
            "gtin": _text(offer, "barcode", "gtin"),
            "category": _text(offer, "categoryId", "category"),
            "clothing_type": _text(offer, "typePrefix", "product_type"),
            "size": _text(offer, "size") or _param(offer, "size", "размер"),
            "color": _text(offer, "color") or _param(offer, "color", "цвет"),
            "material": _text(offer, "material") or _param(offer, "material", "состав", "материал"),
            "gender": _text(offer, "gender") or _param(offer, "gender", "пол"),
            "season": _text(offer, "season") or _param(offer, "season", "сезон"),
            "price": price,
            "currency": currency,
            "url": _link(offer),
            "in_stock": available in {"true", "1", "yes"},
            "seller": source,
        })

    # RSS/Atom entries. Namespaces and Atom link href are supported.
    if not rows:
        entries = [n for n in root.iter() if _local(n.tag) in {"item", "entry"}]
        for item in entries:
            title = _text(item, "title", "name")
            price = _price(_text(item, "price", "amount"))
            link = _link(item)
            if not title or price is None or not link:
                continue
            rows.append({"external_id": link, "title": title, "price": price,
                         "currency": "RUB", "url": link, "seller": source,
                         "in_stock": None})
    return rows


async def fetch_feed(source: str, url: str) -> list[dict]:
    _validate_feed_url(url)
    timeout = httpx.Timeout(15.0, connect=8.0)
    async with httpx.AsyncClient(timeout=timeout, follow_redirects=False,
                                 headers={"User-Agent": USER_AGENT}) as client:
        async with client.stream("GET", url) as response:
            response.raise_for_status()
            content_type = response.headers.get("content-type", "").lower()
            if "html" in content_type:
                raise ValueError("HTML pages are not accepted; configure an XML/YML/CSV feed")
            declared = response.headers.get("content-length")
            if declared and int(declared) > MAX_FEED_BYTES:
                raise ValueError("Feed is larger than 8 MB")
            chunks, size = [], 0
            async for chunk in response.aiter_bytes():
                size += len(chunk)
                if size > MAX_FEED_BYTES:
                    raise ValueError("Feed is larger than 8 MB")
                chunks.append(chunk)
    return parse_yml_or_rss(b"".join(chunks).decode("utf-8-sig", errors="replace"), source)
