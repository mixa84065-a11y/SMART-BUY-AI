from app.discovery import parse_yml_or_rss


def test_namespaced_yml_and_offer_attributes():
    xml = '''<?xml version="1.0"?>
    <yml_catalog xmlns="urn:test"><shop><currencies><currency id="RUB" rate="1"/></currencies>
      <offers><offer id="sku-1" available="true"><name>Куртка</name><price>1299.50</price>
        <currencyId>RUB</currencyId><url>https://shop.example/item/1</url>
        <vendor>Brand</vendor><param name="Размер">M</param><param name="Цвет">Чёрный</param>
      </offer></offers></shop></yml_catalog>'''
    rows = parse_yml_or_rss(xml, "shop")
    assert len(rows) == 1
    assert rows[0]["title"] == "Куртка"
    assert rows[0]["price"] == 1299.5
    assert rows[0]["size"] == "M"
    assert rows[0]["color"] == "Чёрный"


def test_atom_entry_link_href():
    xml = '''<feed xmlns="http://www.w3.org/2005/Atom"><entry><title>Книга</title>
      <price>450</price><link href="https://shop.example/book"/></entry></feed>'''
    rows = parse_yml_or_rss(xml, "bookshop")
    assert len(rows) == 1
    assert rows[0]["url"] == "https://shop.example/book"
    assert rows[0]["price"] == 450


def test_rejects_dtd_entities():
    xml = '<!DOCTYPE x [<!ENTITY e "boom">]><rss><channel/></rss>'
    try:
        parse_yml_or_rss(xml, "x")
        assert False, "DTD should be rejected"
    except ValueError as exc:
        assert "DTD" in str(exc)


def test_matching_uses_gtin_as_strong_identity():
    from types import SimpleNamespace
    from app.matching import strong_match
    product = SimpleNamespace(gtin="4601234567890", brand="Acme", model="X-100", title="Товар")
    matched, basis = strong_match(product, gtin="460 123 456 7890", brand="Other", model="Y", title="Другое")
    assert matched is True
    assert basis == "gtin"


def test_matching_requires_exact_identity_for_automatic_merge():
    from types import SimpleNamespace
    from app.matching import strong_match, candidate_score
    product = SimpleNamespace(gtin=None, brand="Acme", model="X100", title="Наушники Acme X100")
    matched, _ = strong_match(product, gtin=None, brand="Acme", model="X-100", title="Наушники Acme X100")
    assert matched is False
    score, reason = candidate_score(product, title="Наушники Acme X100 Pro", brand="Acme", model=None, gtin=None)
    assert score >= 0.62
    assert "похожее" in reason.lower()


def test_review_import_schema_separates_product_and_seller():
    from app.schemas import ReviewImportIn
    payload = ReviewImportIn(reviews=[{
        "external_id": "r-1", "product_id": 1, "source": "partner_feed",
        "review_type": "product", "rating": 4.5, "body": "Хороший товар"
    }])
    assert payload.reviews[0].review_type == "product"

def test_review_import_schema_rejects_unknown_review_type():
    from pydantic import ValidationError
    from app.schemas import ReviewImportIn
    try:
        ReviewImportIn(reviews=[{
            "external_id": "r-2", "product_id": 1, "source": "partner_feed",
            "review_type": "unknown", "rating": 5
        }])
        assert False, "unknown review type must be rejected"
    except ValidationError:
        pass
