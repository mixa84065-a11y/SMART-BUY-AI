# SMART BUY AI — Android MVP starter

Русскоязычный Android-проект для российского рынка. Package ID: `com.smartbuy.ai`.

## Текущая демо-версия
- Главная страница, поиск по локальному демонстрационному каталогу и категории, включая женскую/мужскую/детскую одежду, обувь и аксессуары.
- Карточки товаров и демонстрационное сравнение трёх условных предложений.
- Раздел со списком целевых российских и международных источников.
- Отдельно предусмотрены отзывы о товаре и отзывы о продавце/магазине.
- Избранное и отслеживание с локальным сохранением.
- Профиль и экран Premium.
- GitHub Actions для сборки debug APK.

## Целевые источники
### Россия
Wildberries, Ozon, Яндекс Маркет, Мегамаркет, DNS, Ситилинк, М.Видео, Эльдорадо, ВсеИнструменты.ру, Детский мир.

### Одежда, обувь и аксессуары
Lamoda, Спортмастер, Kari, Gloria Jeans, O'STIN, Befree, Zarina, Love Republic, Henderson, Rendez-Vous. Это целевые источники; активное подключение возможно только через разрешённые фиды, партнёрский доступ или лицензированного поставщика.

### Международные
AliExpress (розничные предложения), Alibaba.com (оптовые предложения, минимальная партия/MOQ, цена за единицу и стоимость партии).

**Важно:** перечисление — план интеграций, не подтверждение действующего доступа. Текущие товары, цены, названия магазинов и предложения в демо-каталоге условные. Реальные цены, остатки, отзывы и рейтинги пока не загружаются. Не использовать демо-значения как коммерческие сведения.

## Принципы сравнения
- Сопоставлять один и тот же товар по бренду, модели, SKU/GTIN/EAN и характеристикам.
- Разделять цену товара, доставку, налоги/пошлины и итоговую стоимость.
- Учитывать регион доставки и дату/время обновления предложения.
- Не смешивать розничные цены с оптовыми: для Alibaba показывать MOQ, цену за единицу при указанном объёме и стоимость всей партии.
- Разделять отзывы о товаре и отзывы о продавце/магазине.
- Для каждого отзыва хранить площадку, дату, оценку, ссылку на первоисточник и контекст товара; показывать только данные, которые разрешено получать и отображать.
- AI-резюме отзывов должно указывать повторяющиеся плюсы/минусы и не подменять исходные отзывы.

## Источники данных и доступ
Интеграции должны выполняться через официальные API, партнёрские фиды, лицензированных поставщиков данных или письменное разрешение площадки. У API могут быть ограничения: некоторые интерфейсы доступны только продавцам или одобренным партнёрам. Для коммерческого независимого агрегатора потребуется согласовать доступ и условия использования отдельно для каждого источника. Не обходить CAPTCHA, авторизацию, технические ограничения или запреты площадок.

## Архитектура следующего этапа
1. Backend API и база товаров/цен/отзывов.
2. Отдельный адаптер и статус доступа для каждого источника.
3. Нормализация товаров по GTIN/EAN, бренду, модели и характеристикам.
4. Сбор истории цен и серверные уведомления.
5. Отдельный расчёт landed cost для международных и оптовых заказов.
6. AI-анализ отзывов и рекомендация с указанием уверенности и источников.
7. Реклама, подписки и биллинг после проверки доступности и требований Google Play.
8. Политика конфиденциальности, согласия и правовая проверка требований РФ.

Никакие секретные API-ключи не должны помещаться в APK.

## Backend API (новый этап 0.2.0)
В папке `backend/` добавлен серверный каркас FastAPI + SQLAlchemy:
- единая база товаров, предложений и отзывов;
- раздельные типы отзывов `product` и `seller`;
- отдельный реестр адаптеров площадок и endpoint статусов;
- отдельные поля для оптовых предложений, MOQ и валюты;
- `.env.example` для серверных секретов (не добавлять реальные ключи в APK или Git).

Сейчас все адаптеры намеренно выключены: backend не подделывает живые цены и не собирает данные обходными способами. Инструкция запуска находится в `backend/README.md`.

## Сборка APK через GitHub Actions
1. Создайте репозиторий `SMART-BUY-AI` на GitHub.
2. Загрузите содержимое архива в корень репозитория.
3. Откройте Actions → Build SMART BUY AI APK → Run workflow.
4. Скачайте артефакт `SMART-BUY-AI-debug-APK`.


## Automatic discovery (v0.2.0)

The app now supports a server URL in Profile. When configured, product searches go to the backend's unified discovery endpoint instead of the local demo catalogue. The backend can automatically refresh operator-configured public HTTPS XML/YML or RSS/Atom merchant feeds every 30 minutes. No marketplace API keys are needed for an openly published feed, but the feed must be permitted for this use. No real merchant feed URLs are included by default, and the Android app cannot return live offers until a backend is deployed and at least one permitted feed is configured.


## Clothing filters (v0.3.4)

The Android search screen includes an apparel filter dialog for brand, size, color, material/composition, gender, season, and garment type. When a backend URL is configured, these filters are sent as query parameters to `/v1/discovery/search`. The API applies filters only to attributes actually supplied by an approved merchant feed. YML `<param name="...">` values for size, color, material, gender, and season are parsed. Missing attributes are not guessed. The local demo catalogue remains illustrative and cannot validate exact size/color matches.


## Keyless public web search (v0.3.5)

The Android app now has a no-key search fallback: after entering a product query it displays one-tap searches scoped to supported public store domains using Yandex web search. It covers Russian marketplaces, electronics retailers, clothing/shoe stores, children's retail, AliExpress and Alibaba. This opens public search results in the browser; it is not a direct store integration and does not extract or compare live prices, stock, delivery or reviews. Those values are shown only when supplied by a permitted feed through the backend. The local demo catalogue is explicitly labeled as illustrative. No API key is required for the browser-search fallback.


## More stores and home category (v0.3.6)

The keyless search directory now includes additional store groups: home goods, furniture, interior, DIY/renovation, beauty, books, auto parts, and pet supplies. Examples include Hoff, Лемана ПРО, Петрович, Максидом, ВсеИнструменты.ру, Askona, divan.ru, Столплит, Много мебели, Твой Дом, Kuchenland, Золотое Яблоко, Лэтуаль, Рив Гош, Читай-город, Book24, Exist, Автодок, Petshop, and Четыре Лапы.

These are searchable public web destinations, not confirmed live catalog integrations. Search results are opened in the browser; the app does not scrape restricted pages or claim live prices without an authorized feed.


## Store directory update (v0.3.7)

Added the Russian discount retailer **Ещё** (`eshe.club`) as a separate source in the home-goods / everyday-shopping group and in the keyless store-search list. The source list also includes a direct button to the official site. Search-by-domain opens public web-index results; it does not scrape the store site or import its prices, stock, ratings, or reviews. The official site's terms reserve commercial reuse of its site content, so SMART BUY AI does not copy or republish its catalog content.

The official site describes categories including home goods, kitchenware, home textiles, decor, beauty, clothing, toys, food, and everyday family goods. Availability and pickup/delivery conditions depend on region and the official store.

## Search quality and offer freshness (v0.3.8)

- XML/YML parsing now handles namespaced YML and namespaced RSS/Atom entries, including Atom `<link href="...">` links.
- The importer rejects DTD/entity declarations, caps streamed feed downloads at 8 MB, rejects non-standard HTTPS ports, and still refuses redirects and HTML pages.
- Search results include a computed total (item price + known shipping), offer age, and a freshness label. Offers older than 24 hours are marked for manual price verification; this is a warning, not a guarantee that a retailer's live price is unchanged.
- Retail and wholesale offers are labeled separately in the Android result list. Do not compare Alibaba bulk prices with retail offers as if they were equivalent.
- Added more target retailers to the backend connector-status registry, including «Ещё» and home/furniture stores. Their status remains not configured until an authorized feed or partner access is supplied.
- Backend parser tests cover namespaced YML, Atom link attributes, and DTD rejection.

**Build status:** backend unit tests pass. Android APK build has not been run in this environment; use the included GitHub Actions workflow to build the debug APK.


## Версия 0.3.9 — сопоставление одинаковых товаров

- Добавлен консервативный механизм идентификации: сначала GTIN/EAN/UPC, затем нормализованные бренд+модель, затем точное название с брендом.
- Похожие названия выдаются отдельным списком кандидатов через `GET /v1/matching/candidates`; нечёткие совпадения не объединяются автоматически.
- Розничные и оптовые предложения показываются раздельно; итоговая цена учитывает доставку.
- Для окончательного сравнения проверяйте размер, цвет, комплектацию и регион доставки: совпадение названия не гарантирует идентичность товара.
- APK не включён: Android-сборку необходимо выполнить через GitHub Actions или Android/Termux-совместимую среду.


## v0.4.0 — экран сопоставления товаров

- После автоматического поиска Android дополнительно запрашивает `/v1/matching/candidates`.
- Отображаются оценка совпадения, причина, розничные предложения и отдельный блок оптовых предложений.
- Слабые совпадения явно помечаются как требующие проверки; они не выдаются за подтверждённо одинаковые товары.
- Предложения с URL открываются по нажатию; итоговая цена включает доставку, если она указана источником.
- Если endpoint сопоставления недоступен, результаты основного поиска остаются на экране.

Версия Android: `0.4.0` (`versionCode 9`). Для реального сравнения нужны импортированные разрешённые фиды; демонстрационные цены не используются в этом блоке.


## v0.5.0 — Product intelligence foundations
- Added price snapshots captured when permitted feed offers are first imported or their price/shipping/currency changes.
- Added price history, review summary/import, and evidence-based current-offer recommendation endpoints.
- Android product details now expose history/review/recommendation sections for server-backed products.
- Added local target-price alert settings, favorites/tracking UI, and an ad placement placeholder.
- Premium and advertising are UI-only placeholders; Google Play Billing and an ad network are not integrated.
- Demo catalogue prices remain explicitly marked as demo and are never used as live market evidence.


## Версия 0.5.1 — единый интерфейс
- Унифицированы заголовки страниц, карточки-подсказки и кнопки действий.
- Нижняя навигация использует одинаковые русские подписи: «Главная», «Избранное», «Цены», «Профиль»; активный раздел подсвечивается.
- Приведены к единому стилю подписи действий и убраны повторяющиеся кнопки в карточке товара.
- Это обновление интерфейса; APK в этой среде не собирался.


## Обновление без удаления приложения (v0.5.2)

Для обновления поверх установленной версии Android должны совпадать три условия:

1. `applicationId` остаётся `com.smartbuy.ai` — не меняйте его.
2. `versionCode` каждой следующей сборки увеличивается (сейчас 12).
3. APK подписан **тем же самым закрытым ключом**, что и установленная версия. Потеря или замена ключа может потребовать удаления приложения; резервную копию keystore храните в надёжном месте.

Настроен workflow `.github/workflows/android.yml` для выпуска подписанного Release APK. В настройках GitHub-репозитория добавьте Actions secrets:
- `SMARTBUY_KEYSTORE_BASE64` — keystore в Base64;
- `SMARTBUY_KEYSTORE_PASSWORD` — пароль keystore;
- `SMARTBUY_KEY_ALIAS` — alias ключа;
- `SMARTBUY_KEY_PASSWORD` — пароль ключа.

После настройки запустите GitHub Actions → Build SMART BUY AI update APK → Run workflow и установите скачанный APK **поверх** существующего. Не удаляйте приложение и не очищайте данные. Локальные настройки и избранное хранятся в SharedPreferences и при обычном обновлении сохраняются.

Важно: если ранее установленный APK был собран как debug на временном GitHub runner, его подпись могла отличаться от постоянного Release-ключа. Такой APK нельзя гарантированно обновить этим ключом. Для точной проверки совместимости нужна подпись (сертификат) уже установленного APK. После перехода на один постоянный ключ последующие обновления будут устанавливаться поверх без удаления при соблюдении условий выше.

## Постоянная подпись для обновлений без удаления

Для сборки обновляемого release APK workflow требует Repository secrets: `SMARTBUY_KEYSTORE_BASE64`, `SMARTBUY_KEYSTORE_PASSWORD`, `SMARTBUY_KEY_ALIAS`, `SMARTBUY_KEY_PASSWORD`. Инструкция и приватный ключ передаются владельцу отдельно в комплекте `SMART_BUY_AI_Permanent_Signing_Kit.zip`. Не публикуйте и не теряйте ключ. Совместимость с ранее установленным APK зависит от совпадения applicationId и сертификата подписи; сертификат предыдущего APK ещё нужно проверить.


## Загрузка проекта в GitHub и постоянная подпись

1. Создайте отдельный пустой репозиторий `SMART-BUY-AI` в своём GitHub аккаунте. Не используйте репозиторий другого приложения.
2. Загрузите в него содержимое этого архива, а не сам ZIP-файл. Каталог `signing/` намеренно не включён: приватный ключ и пароли нельзя публиковать в репозитории.
3. В Settings → Secrets and variables → Actions добавьте четыре Repository secrets: `SMARTBUY_KEYSTORE_BASE64`, `SMARTBUY_KEYSTORE_PASSWORD`, `SMARTBUY_KEY_ALIAS`, `SMARTBUY_KEY_PASSWORD`. Значения находятся в отдельном приватном комплекте подписи.
4. Откройте Actions → Build SMART BUY AI update APK → Run workflow. Установите полученный APK только после проверки подписи установленного приложения.

**Важно:** package ID проекта — `com.smartbuy.ai`, versionCode — 12. Это позволяет Android рассматривать сборку как обновление по идентификатору, но Android также требует совпадения сертификата подписи. Ранее собранный debug APK может быть подписан другим сертификатом. Пока сертификат установленной версии не извлечён и не сравнён с постоянным сертификатом, обещать обновление поверх без удаления нельзя.
