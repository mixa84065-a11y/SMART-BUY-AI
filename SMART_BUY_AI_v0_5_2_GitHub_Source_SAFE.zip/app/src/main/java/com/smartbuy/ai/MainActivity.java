package com.smartbuy.ai;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.widget.*;
import org.json.*;
import java.net.*;
import java.io.*;
import java.util.*;

public class MainActivity extends Activity {
    final int BG=0xFF0B1020, PANEL=0xFF151D32, PANEL2=0xFF1D2942, TEXT=0xFFF4F6FF,
        MUTED=0xFF9AA8C4, PURPLE=0xFF8B78FF, GREEN=0xFF48D6A0, GOLD=0xFFFFC86B;
    LinearLayout root, content, nav;
    String activeNav="Главная";
    EditText search;
    SharedPreferences prefs;
    String activeCategory="Все";
    final String[] categories={"Все","Электроника","Телефоны","Компьютеры","Дом","Мебель","Интерьер","Сад и ремонт","Одежда","Женская одежда","Мужская одежда","Обувь","Аксессуары","Детская одежда","Красота","Спорт","Детям","Авто","Продукты","Зоотовары","Книги"};
    final ArrayList<Product> products=new ArrayList<>();
    static class Product {
        String name, category, emoji;
        int p1,p2,p3;
        String shop1,shop2,shop3;
        Product(String n,String c,String e,int a,int b,int d,String s1,String s2,String s3){
            name=n;category=c;emoji=e;p1=a;p2=b;p3=d;shop1=s1;shop2=s2;shop3=s3;
        }
        int min(){return Math.min(p1,Math.min(p2,p3));}
    }
    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        getWindow().setStatusBarColor(BG);getWindow().setNavigationBarColor(BG);
        prefs=getSharedPreferences("smartbuy",MODE_PRIVATE);
        seed();
        root=new LinearLayout(this);root.setOrientation(1);root.setBackgroundColor(BG);root.setPadding(dp(16),dp(14),dp(16),dp(8));setContentView(root);
        header();
        content=new LinearLayout(this);content.setOrientation(1);
        ScrollView sc=new ScrollView(this);sc.setFillViewport(true);sc.addView(content);
        root.addView(sc,new LinearLayout.LayoutParams(-1,0,1));
        nav();
        home();
    }
    void seed(){
        products.add(new Product("Apple iPhone 15 128 ГБ","Телефоны","📱",62990,64990,61990,"Магазин A","Магазин B","Магазин C"));
        products.add(new Product("Samsung Galaxy A55 256 ГБ","Телефоны","📱",31990,29990,32490,"Магазин A","Магазин B","Магазин C"));
        products.add(new Product("Наушники Sony WH-1000XM5","Электроника","🎧",28990,26990,29490,"Магазин A","Магазин B","Магазин C"));
        products.add(new Product("Ноутбук ASUS VivoBook 15","Компьютеры","💻",54990,56990,52990,"Магазин A","Магазин B","Магазин C"));
        products.add(new Product("Робот-пылесос Xiaomi S10","Дом","🤖",17990,16990,18490,"Магазин A","Магазин B","Магазин C"));
        products.add(new Product("Кроссовки спортивные","Одежда","👟",4990,4590,5290,"Магазин A","Магазин B","Магазин C"));
        products.add(new Product("Умные часы Amazfit GTS","Электроника","⌚",8990,8490,9290,"Магазин A","Магазин B","Магазин C"));
        products.add(new Product("Кофемашина автоматическая","Дом","☕",39990,37990,41990,"Магазин A","Магазин B","Магазин C"));
        products.add(new Product("Фен для волос","Красота","💨",6990,6490,7290,"Магазин A","Магазин B","Магазин C"));
        products.add(new Product("Фитнес-браслет","Спорт","🏃",3990,3790,4290,"Магазин A","Магазин B","Магазин C"));
        products.add(new Product("Детский конструктор","Детям","🧸",2490,2290,2690,"Магазин A","Магазин B","Магазин C"));
        products.add(new Product("Автомобильный видеорегистратор","Авто","🚗",5990,5690,6290,"Магазин A","Магазин B","Магазин C"));
        products.add(new Product("Кофе молотый 250 г","Продукты","🛍️",490,520,470,"Магазин A","Магазин B","Магазин C"));
        products.add(new Product("Женское платье повседневное","Женская одежда","👗",3490,3290,3790,"Магазин A","Магазин B","Магазин C"));
        products.add(new Product("Мужская куртка демисезонная","Мужская одежда","🧥",6990,6490,7290,"Магазин A","Магазин B","Магазин C"));
        products.add(new Product("Кроссовки повседневные","Обувь","👟",5990,5490,6290,"Магазин A","Магазин B","Магазин C"));
        products.add(new Product("Рюкзак городской","Аксессуары","🎒",2990,2790,3290,"Магазин A","Магазин B","Магазин C"));
        products.add(new Product("Детская толстовка","Детская одежда","🧒",1990,1790,2190,"Магазин A","Магазин B","Магазин C"));
    }
    void header(){
        LinearLayout h=new LinearLayout(this);h.setGravity(Gravity.CENTER_VERTICAL);
        TextView logo=txt("◈",30,PURPLE,true);h.addView(logo);
        LinearLayout names=new LinearLayout(this);names.setOrientation(1);names.setPadding(dp(8),0,0,0);
        names.addView(txt("SMART BUY AI",18,TEXT,true));names.addView(txt("Покупай умнее",10,MUTED,true));
        h.addView(names,new LinearLayout.LayoutParams(0,-2,1));
        TextView pro=txt("Premium",10,GOLD,true);pro.setPadding(dp(11),dp(8),dp(11),dp(8));pro.setBackground(round(0xFF3B3024,24));pro.setOnClickListener(v->premium());h.addView(pro);
        root.addView(h);
        View line=new View(this);line.setBackgroundColor(0xFF25314B);
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,dp(1));lp.setMargins(0,dp(12),0,dp(10));root.addView(line,lp);
    }
    void nav(){
        nav=new LinearLayout(this);nav.setGravity(Gravity.CENTER);nav.setPadding(0,dp(8),0,0);
        buildNav();
        root.addView(nav);
    }
    void buildNav(){
        if(nav==null)return;
        nav.removeAllViews();
        String[] labels={"Главная","Избранное","Цены","Профиль"};String[] icons={"⌂","♡","◷","☻"};
        for(int i=0;i<labels.length;i++){
            final int ix=i;boolean selected=labels[i].equals(activeNav);
            LinearLayout item=new LinearLayout(this);item.setOrientation(1);item.setGravity(Gravity.CENTER);
            item.setPadding(0,dp(5),0,dp(4));
            item.addView(txt(icons[i],21,selected?PURPLE:MUTED,true));
            item.addView(txt(labels[i],10,selected?TEXT:MUTED,selected));
            item.setOnClickListener(v->{if(ix==0)home();if(ix==1)favorites();if(ix==2)tracking();if(ix==3)profile();});
            nav.addView(item,new LinearLayout.LayoutParams(0,dp(54),1));
        }
    }
    void reset(String title,String subtitle){
        content.removeAllViews();
        if(title!=null){
            if(title.equals("Избранное"))activeNav="Избранное";
            else if(title.equals("Цены")||title.equals("Отслеживание цен"))activeNav="Цены";
            else if(title.equals("Профиль"))activeNav="Профиль";
            else if(title.equals("Найди лучшую цену")||title.equals("Результаты поиска")||title.equals("Автоматический поиск"))activeNav="Главная";
            buildNav();
            LinearLayout pageHead=new LinearLayout(this);pageHead.setOrientation(1);
            pageHead.setPadding(dp(14),dp(13),dp(14),dp(13));
            pageHead.setBackground(round(PANEL,16));
            pageHead.addView(txt(title,22,TEXT,true));
            if(subtitle!=null&&!subtitle.isEmpty()){
                TextView sub=txt(subtitle,12,MUTED,false);sub.setPadding(0,dp(4),0,0);pageHead.addView(sub);
            }
            LinearLayout.LayoutParams hp=new LinearLayout.LayoutParams(-1,-2);hp.setMargins(0,dp(2),0,dp(10));
            content.addView(pageHead,hp);
        }
    }
    void home(){
        reset("Найди лучшую цену","Сравнивай предложения и экономь на покупках");
        search=new EditText(this);search.setSingleLine(true);search.setTextColor(TEXT);search.setHintTextColor(MUTED);search.setHint("  Поиск товаров, брендов и моделей");search.setTextSize(14);search.setPadding(dp(14),dp(10),dp(14),dp(10));search.setBackground(round(PANEL,16));
        LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(-1,dp(48));sp.setMargins(0,dp(16),0,dp(12));content.addView(search,sp);
        search.setOnEditorActionListener((v,a,e)->{renderSearch(search.getText().toString());return true;});
        TextView clothingFilters=action("Фильтры одежды  ⚙",PANEL2); content.addView(clothingFilters);
        clothingFilters.setOnClickListener(v->showClothingFilters());
        TextView go=action("Искать товары  →",PURPLE);content.addView(go);go.setOnClickListener(v->renderSearch(search.getText().toString()));
        content.addView(section("Категории"));
        LinearLayout row=new LinearLayout(this);row.setOrientation(1);
        for(int start=0;start<categories.length;start+=4){LinearLayout r=new LinearLayout(this);for(int j=start;j<Math.min(start+4,categories.length);j++){String c=categories[j];TextView chip=txt(c,10,c.equals(activeCategory)?Color.WHITE:MUTED,true);chip.setGravity(Gravity.CENTER);chip.setPadding(dp(5),dp(10),dp(5),dp(10));chip.setBackground(round(c.equals(activeCategory)?0xFF51478F:PANEL,12));LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(0,-2,1);cp.setMargins(dp(2),dp(3),dp(2),dp(3));r.addView(chip,cp);chip.setOnClickListener(v->{activeCategory=c;home();});}row.addView(r);}
        content.addView(row);
        content.addView(section("Магазины и маркетплейсы"));
        content.addView(note("Маркетплейсы и универсальные магазины",
                "Wildberries • Ozon • Яндекс Маркет • Мегамаркет • Авито • AliExpress • Alibaba"));
        content.addView(note("Электроника и техника",
                "DNS • Ситилинк • М.Видео • Эльдорадо • Онлайнтрейд • Холодильник.ру"));
        content.addView(note("Дом, мебель, интерьер и ремонт",
                "Hoff • Лемана ПРО • Петрович • Максидом • ВсеИнструменты.ру • Askona • divan.ru • Столплит • Много мебели • Твой Дом • Kuchenland • Ещё"));
        content.addView(note("Одежда, обувь и аксессуары",
                "Lamoda • Спортмастер • Kari • Gloria Jeans • O'STIN • Befree • Zarina • Love Republic • Henderson • Rendez-Vous • Детский мир"));
        TextView sources = action("Показать все источники  →", PANEL2);
        content.addView(sources);
        sources.setOnClickListener(v -> sourceList());
        content.addView(section("Выгодные предложения"));
        adBanner();
        for(Product p:products){if(activeCategory.equals("Все")||p.category.equals(activeCategory))productCard(p);}
        content.addView(note("Поиск без API-ключей","Введи товар и открой поисковые страницы магазинов. Демо-цены ниже не являются реальными предложениями."));
    }
    void showClothingFilters(){
        LinearLayout form=new LinearLayout(this); form.setOrientation(1); form.setPadding(dp(18),dp(8),dp(18),dp(4));
        String[] keys={"brand","size","color","material","gender","season","clothing_type"};
        String[] labels={"Бренд","Размер (например M, 42, 38)","Цвет","Материал / состав","Пол (женский, мужской, детский)","Сезон","Тип вещи (куртка, платье, кроссовки)"};
        EditText[] fields=new EditText[keys.length];
        for(int i=0;i<keys.length;i++){
            TextView label=txt(labels[i],11,MUTED,true); form.addView(label);
            EditText field=new EditText(this); field.setSingleLine(true); field.setTextColor(TEXT); field.setHintTextColor(MUTED); field.setTextSize(13); field.setHint("Любое значение");
            field.setText(prefs.getString("clothing_"+keys[i],"")); field.setPadding(dp(10),dp(7),dp(10),dp(7)); field.setBackground(round(PANEL,10));
            LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,dp(42)); lp.setMargins(0,0,0,dp(7)); form.addView(field,lp); fields[i]=field;
        }
        ScrollView scroll=new ScrollView(this); scroll.addView(form);
        new AlertDialog.Builder(this).setTitle("Фильтры одежды и обуви").setView(scroll)
            .setNegativeButton("Сбросить",(d,w)->{SharedPreferences.Editor ed=prefs.edit();for(String k:keys)ed.remove("clothing_"+k);ed.apply();Toast.makeText(this,"Фильтры сброшены",Toast.LENGTH_SHORT).show();})
            .setNeutralButton("Отмена",null)
            .setPositiveButton("Применить",(d,w)->{SharedPreferences.Editor ed=prefs.edit();for(int i=0;i<keys.length;i++)ed.putString("clothing_"+keys[i],fields[i].getText().toString().trim());ed.apply();Toast.makeText(this,"Фильтры сохранены",Toast.LENGTH_SHORT).show();}).show();
    }
    void renderSearch(String q){
        if(q.trim().isEmpty()){home();return;}
        String server = prefs.getString("api_base_url", "").trim();
        if(!server.isEmpty()){ remoteSearch(q, server); return; }
        keylessStoreSearch(q);
        content.addView(section("Локальный демонстрационный каталог"));
        content.addView(note("Важно", "Карточки ниже — примеры интерфейса, не реальные цены и не актуальные предложения."));
        String type=prefs.getString("clothing_clothing_type","").trim().toLowerCase();
        int count=0;for(Product p:products)if((p.name.toLowerCase().contains(q.toLowerCase())||p.category.toLowerCase().contains(q.toLowerCase()))&&(type.isEmpty()||p.name.toLowerCase().contains(type)||p.category.toLowerCase().contains(type))){productCard(p);count++;}
        if(count==0)content.addView(note("В демо-каталоге совпадений нет","Воспользуйся поиском по магазинам выше — он работает без API-ключей."));
    }

    static class StoreSearch { String name, domain, group; StoreSearch(String n,String d,String g){name=n;domain=d;group=g;} }
    void keylessStoreSearch(String q){
        reset("Поиск без API-ключей", "Запрос: «"+q+"» • открываемые поисковые страницы магазинов");
        content.addView(note("Как это работает", "SMART BUY AI формирует поисковые запросы по магазинам. Нажми на магазин, чтобы открыть найденные публичные страницы в браузере. Цены и наличие проверяй на сайте продавца — автоматическое сравнение пока доступно только для подключённых разрешённых фидов."));
        String[][] stores={
            {"Wildberries","wildberries.ru","Маркетплейсы"},{"Ozon","ozon.ru","Маркетплейсы"},{"Яндекс Маркет","market.yandex.ru","Маркетплейсы"},{"Мегамаркет","megamarket.ru","Маркетплейсы"},{"Авито","avito.ru","Маркетплейсы и объявления"},
            {"DNS","dns-shop.ru","Электроника и техника"},{"Ситилинк","citilink.ru","Электроника и техника"},{"М.Видео","mvideo.ru","Электроника и техника"},{"Эльдорадо","eldorado.ru","Электроника и техника"},{"Онлайнтрейд","onlinetrade.ru","Электроника и техника"},{"Холодильник.ру","holodilnik.ru","Электроника и техника"},
            {"Hoff","hoff.ru","Дом, мебель и интерьер"},{"Лемана ПРО","lemanapro.ru","Дом, мебель и ремонт"},{"Петрович","petrovich.ru","Дом, мебель и ремонт"},{"Максидом","maxidom.ru","Дом, мебель и ремонт"},{"ВсеИнструменты.ру","vseinstrumenti.ru","Дом, мебель и ремонт"},{"Askona","askona.ru","Дом, мебель и интерьер"},{"divan.ru","divan.ru","Дом, мебель и интерьер"},{"Столплит","stolplit.ru","Дом, мебель и интерьер"},{"Много мебели","mnogomebeli.com","Дом, мебель и интерьер"},{"Твой Дом","tvoydom.ru","Дом, мебель и интерьер"},{"Kuchenland","kuchenland.ru","Дом, мебель и интерьер"},{"Ещё","eshe.club","Дом, товары для семьи и повседневные покупки"},
            {"Lamoda","lamoda.ru","Одежда и обувь"},{"Спортмастер","sportmaster.ru","Одежда и обувь"},{"Kari","kari.com","Одежда и обувь"},{"Gloria Jeans","gloria-jeans.ru","Одежда и обувь"},{"O'STIN","ostin.com","Одежда и обувь"},{"Befree","befree.ru","Одежда и обувь"},{"Zarina","zarina.ru","Одежда и обувь"},{"Love Republic","loverepublic.ru","Одежда и обувь"},{"Henderson","henderson.ru","Одежда и обувь"},{"Rendez-Vous","rendez-vous.ru","Одежда и обувь"},
            {"Золотое Яблоко","goldapple.ru","Красота и уход"},{"Лэтуаль","letu.ru","Красота и уход"},{"Рив Гош","rivegauche.ru","Красота и уход"},
            {"Читай-город","chitai-gorod.ru","Книги и канцелярия"},{"Book24","book24.ru","Книги и канцелярия"},
            {"Exist","exist.ru","Авто и запчасти"},{"Автодок","autodoc.ru","Авто и запчасти"},
            {"Petshop","petshop.ru","Зоотовары"},{"Четыре Лапы","4lapy.ru","Зоотовары"},
            {"AliExpress","aliexpress.ru","Международные площадки"},{"Alibaba","alibaba.com","Международные площадки"}
        };
        String last="";
        for(String[] row:stores){
            if(!row[2].equals(last)){content.addView(section(row[2]));last=row[2];}
            String store=row[0],domain=row[1].trim();
            TextView item=action("⌕  "+store+"  —  искать «"+q+"»",PANEL2);content.addView(item);
            item.setOnClickListener(v->openStoreSearch(q,store,domain));
        }
        content.addView(note("Ограничения", "Это поиск по публичной веб-индексации, а не прямое подключение магазинов. Результаты могут быть неполными или устаревшими. Без официального фида/API приложение не получает достоверные цены, остатки, отзывы и доставку автоматически."));
    }
    void openStoreSearch(String q,String store,String domain){
        try{
            String query="site:"+domain+" "+q;
            String url="https://yandex.ru/search/?text="+java.net.URLEncoder.encode(query,"UTF-8");
            Intent intent=new Intent(Intent.ACTION_VIEW,Uri.parse(url));
            startActivity(intent);
        }catch(Exception e){Toast.makeText(this,"Не удалось открыть поиск",Toast.LENGTH_SHORT).show();}
    }

    void productCard(Product p){
        LinearLayout card=new LinearLayout(this);card.setOrientation(1);card.setPadding(dp(13),dp(12),dp(13),dp(12));card.setBackground(round(PANEL,18));
        LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,-2);cp.setMargins(0,dp(6),0,dp(6));content.addView(card,cp);
        LinearLayout top=new LinearLayout(this);top.setGravity(Gravity.CENTER_VERTICAL);
        TextView em=txt(p.emoji,29,TEXT,true);em.setGravity(Gravity.CENTER);em.setBackground(round(PANEL2,14));top.addView(em,new LinearLayout.LayoutParams(dp(54),dp(54)));
        TextView name=txt(p.name,13,TEXT,true);name.setPadding(dp(10),0,dp(4),0);top.addView(name,new LinearLayout.LayoutParams(0,-2,1));
        TextView fav=txt(isFav(p)?"♥":"♡",23,isFav(p)?0xFFFF7799:MUTED,true);top.addView(fav);fav.setOnClickListener(v->{toggleFav(p);home();});
        card.addView(top);
        LinearLayout prices=new LinearLayout(this);prices.setGravity(Gravity.CENTER_VERTICAL);prices.setPadding(0,dp(10),0,dp(5));
        TextView best=txt("от "+money(p.min()),17,GREEN,true);prices.addView(best,new LinearLayout.LayoutParams(0,-2,1));
        TextView compare=txt("Сравнить  →",10,0xFFBDB2FF,true);prices.addView(compare);card.addView(prices);
        TextView info=txt("3 предложения • "+p.category,10,MUTED,false);card.addView(info);
        card.setOnClickListener(v->detail(p));
    }
    void detail(Product p){
        reset("Карточка товара",p.category);
        TextView hero=txt(p.emoji,56,TEXT,true);hero.setGravity(Gravity.CENTER);hero.setBackground(round(PANEL,20));LinearLayout.LayoutParams hp=new LinearLayout.LayoutParams(-1,dp(120));hp.setMargins(0,dp(14),0,dp(12));content.addView(hero,hp);
        content.addView(txt(p.name,20,TEXT,true));content.addView(txt("Предложения магазинов",13,MUTED,false));
        offer(p.shop1,p.p1);offer(p.shop2,p.p2);offer(p.shop3,p.p3);
        content.addView(section("Отзывы и репутация"));
        content.addView(note("Анализ отзывов появится после подключения источников",
                "Будем разделять отзывы о товаре и отзывы о продавце: качество, доставка, подлинность, возвраты и повторяющиеся жалобы. Сейчас реальные отзывы не загружаются."));
        content.addView(section("История цен"));
        content.addView(note("Исторические данные пока недоступны", "Демо-каталог не хранит реальные ежедневные цены. График появится после накопления снимков цен из подключённых фидов."));
        content.addView(section("Отзывы и рейтинги"));
        content.addView(note("Рейтинг товара", "Нет подтверждённых отзывов в демонстрационном каталоге."));
        content.addView(note("Рейтинг продавца", "Оценивается отдельно: доставка, возвраты, подлинность и качество обслуживания. Реальные отзывы пока не подключены."));
        content.addView(section("Рекомендация SMART BUY AI"));
        int spread=Math.max(p.p1,Math.max(p.p2,p.p3))-p.min();
        String advice=spread>p.min()*0.08?"В демо-примере разброс цен заметный. Перед покупкой сравни доставку, наличие и продавца.":"В демо-примере цены близки. Выбирай по надёжности магазина и условиям доставки.";
        content.addView(note("Предварительный совет — не прогноз", advice+" Все указанные здесь цены демонстрационные."));
        TextView notify=action("Настроить уведомление о цене",PANEL2);content.addView(notify);notify.setOnClickListener(v->setPriceAlert(p));
        TextView track=action(isTracked(p)?"✓ Отслеживается":"◷ Отслеживать цену",PURPLE);content.addView(track);track.setOnClickListener(v->{toggleTrack(p);detail(p);});
        TextView fav=action(isFav(p)?"♥ В избранном":"♡ В избранное",PANEL2);content.addView(fav);fav.setOnClickListener(v->{toggleFav(p);detail(p);});
    }
    void adBanner(){
        LinearLayout ad=new LinearLayout(this);ad.setOrientation(1);ad.setPadding(dp(12),dp(9),dp(12),dp(9));ad.setBackground(round(0xFF202A3F,12));
        ad.addView(txt("РЕКЛАМНОЕ МЕСТО",9,GOLD,true));ad.addView(txt("Здесь могут появляться предложения партнёров. Сейчас реклама не загружается.",10,MUTED,false));
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.setMargins(0,dp(8),0,dp(8));content.addView(ad,lp);
    }
    void setPriceAlert(Product p){
        EditText target=new EditText(this);target.setSingleLine(true);target.setInputType(8194);target.setTextColor(TEXT);target.setHintTextColor(MUTED);target.setHint("Например, 5000");target.setText(prefs.getString("alert_"+p.name,""));target.setPadding(dp(12),dp(8),dp(12),dp(8));target.setBackground(round(PANEL,12));
        new AlertDialog.Builder(this).setTitle("Цена для уведомления").setMessage("Сохраним целевую цену на этом устройстве. Автоматическая проверка реальной цены включится после подключения источников.").setView(target).setNegativeButton("Отмена",null).setPositiveButton("Сохранить",(d,w)->{String v=target.getText().toString().trim();try{double value=Double.parseDouble(v.replace(',','.'));if(value<=0)throw new Exception();prefs.edit().putString("alert_"+p.name,v).putBoolean("t_"+p.name,true).apply();Toast.makeText(this,"Целевая цена сохранена",Toast.LENGTH_SHORT).show();}catch(Exception e){Toast.makeText(this,"Введи корректную сумму",Toast.LENGTH_SHORT).show();}}).show();
    }
    void remoteProductDetail(int productId,String server){
        reset("Карточка товара","Загружаем предложения, историю и отзывы из подключённого сервера...");
        new Thread(()->{
            try{
                JSONObject productInfo=fetchJson(server+"/v1/products/"+productId);
                JSONObject history=fetchJson(server+"/v1/products/"+productId+"/price-history?days=90");
                JSONObject summary=fetchJson(server+"/v1/products/"+productId+"/review-summary");
                JSONObject recommendation=fetchJson(server+"/v1/products/"+productId+"/recommendations");
                JSONArray offers=new JSONArray();
                try{JSONArray arr=fetchArray(server+"/v1/products/"+productId+"/offers");for(int i=0;i<arr.length();i++)offers.put(arr.getJSONObject(i));}catch(Exception ignored){}
                JSONObject hist=history;JSONObject rev=summary;JSONObject rec=recommendation;
                runOnUiThread(()->{
                    reset("Карточка товара",productInfo.optString("category","Данные из подключённого сервера"));
                    content.addView(txt(productInfo.optString("title","Товар"),20,TEXT,true));
                    String specs="Бренд: "+productInfo.optString("brand","—")+" • Модель: "+productInfo.optString("model","—")+" • Штрихкод: "+productInfo.optString("gtin","—");
                    content.addView(note("Характеристики",specs));
                    content.addView(note("История цен", "Точек истории: "+(hist.optJSONArray("items")==null?0:hist.optJSONArray("items").length())+". "+hist.optString("note","")));
                    JSONObject sm=rev.optJSONObject("summary");if(sm!=null){JSONObject pr=sm.optJSONObject("product"),sr=sm.optJSONObject("seller");content.addView(note("Отзывы о товаре",pr==null?"Нет данных":"Отзывов: "+pr.optInt("count")+" • средняя оценка: "+(pr.isNull("average_rating")?"нет":pr.optString("average_rating"))));content.addView(note("Отзывы о продавце",sr==null?"Нет данных":"Отзывов: "+sr.optInt("count")+" • средняя оценка: "+(sr.isNull("average_rating")?"нет":sr.optString("average_rating"))));}
                    JSONArray hitems=hist.optJSONArray("items");if(hitems!=null)for(int i=Math.max(0,hitems.length()-12);i<hitems.length();i++){JSONObject point=hitems.optJSONObject(i);if(point!=null)content.addView(note(point.optString("source"),point.optString("total_price")+" "+point.optString("currency")+" • "+point.optString("observed_at")));}
                    JSONObject best=rec.optJSONObject("best_offer");if(best!=null)content.addView(note("Рекомендация SMART BUY AI",best.optString("source")+" — лучшая найденная цена "+best.optString("total_price")+" "+best.optString("currency")+". Это сравнение текущих данных, не прогноз."));else content.addView(note("Рекомендация",rec.optString("note","Недостаточно данных для вывода.")));
                    if(offers.length()>0){content.addView(section("Предложения"));for(int i=0;i<offers.length();i++){JSONObject o=offers.optJSONObject(i);if(o!=null)content.addView(note(o.optString("source"),o.optString("price")+" "+o.optString("currency")+" • доставка "+o.optString("shipping")));}}
                });
            }catch(Exception ex){runOnUiThread(()->{reset("Карточка товара","Не удалось загрузить данные");content.addView(note("Ошибка",ex.getMessage()==null?"Сервер недоступен":ex.getMessage()));});}
        }).start();
    }
    JSONObject fetchJson(String address)throws Exception{HttpURLConnection c=(HttpURLConnection)new URL(address).openConnection();c.setConnectTimeout(7000);c.setReadTimeout(10000);try{InputStream in=c.getInputStream();ByteArrayOutputStream b=new ByteArrayOutputStream();byte[] x=new byte[4096];int n;while((n=in.read(x))!=-1)b.write(x,0,n);return new JSONObject(b.toString("UTF-8"));}finally{c.disconnect();}}
    JSONArray fetchArray(String address)throws Exception{HttpURLConnection c=(HttpURLConnection)new URL(address).openConnection();c.setConnectTimeout(7000);c.setReadTimeout(10000);try{InputStream in=c.getInputStream();ByteArrayOutputStream b=new ByteArrayOutputStream();byte[] x=new byte[4096];int n;while((n=in.read(x))!=-1)b.write(x,0,n);return new JSONArray(b.toString("UTF-8"));}finally{c.disconnect();}}
    void offer(String shop,int price){LinearLayout l=new LinearLayout(this);l.setGravity(Gravity.CENTER_VERTICAL);l.setPadding(dp(12),dp(12),dp(12),dp(12));l.setBackground(round(PANEL,14));LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.setMargins(0,dp(5),0,dp(5));content.addView(l,lp);l.addView(txt(shop,13,TEXT,true),new LinearLayout.LayoutParams(0,-2,1));l.addView(txt(money(price),15,GREEN,true));}
    void sourceList(){
        reset("Источники сравнения","Площадки, которые планируем подключить");
        content.addView(note("Российские маркетплейсы","Wildberries • Ozon • Яндекс Маркет • Мегамаркет"));
        content.addView(note("Российские интернет-магазины","DNS • Ситилинк • М.Видео • Эльдорадо • Онлайнтрейд • Холодильник.ру • Детский мир"));
        content.addView(note("Дом, мебель, интерьер и ремонт","Hoff • Лемана ПРО • Петрович • Максидом • ВсеИнструменты.ру • Askona • divan.ru • Столплит • Много мебели • Твой Дом • Kuchenland • Ещё"));
        content.addView(note("Красота и уход","Золотое Яблоко • Лэтуаль • Рив Гош"));
        content.addView(note("Книги, авто и зоотовары","Читай-город • Book24 • Exist • Автодок • Petshop • Четыре Лапы"));
        content.addView(note("Одежда, обувь и аксессуары","Lamoda • Спортмастер • Kari • Gloria Jeans • O'STIN • Befree • Zarina • Love Republic • Henderson • Rendez-Vous. Это список целевых магазинов, не активные интеграции."));
        content.addView(note("Ещё — магазин низких цен","Официальный сайт: eshe.club. В каталоге представлены товары для дома, семьи и повседневных покупок. Для поиска по запросу используется публичная веб-индексация; прямое получение цен не подключено."));
        TextView esheCatalog = action("Открыть каталог «Ещё»  →", PANEL2); content.addView(esheCatalog);
        esheCatalog.setOnClickListener(v -> { try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://eshe.club/"))); } catch(Exception e) { Toast.makeText(this,"Не удалось открыть сайт",Toast.LENGTH_SHORT).show(); } });
        content.addView(note("Международные площадки","AliExpress — розничные предложения. Alibaba.com — оптовые цены, MOQ и стоимость партии."));
        TextView all = action("Открыть список всех магазинов  →", PANEL2); content.addView(all);
        all.setOnClickListener(v -> keylessStoreSearch("товары"));
        content.addView(note("Отзывы","Отдельно анализируем отзывы о товаре и о продавце/магазине. Показываем дату, площадку и ссылку на первоисточник, если источник разрешает публикацию."));
        content.addView(note("Статус интеграций","Это целевой список. Реальные цены, отзывы и наличие будут отображаться только после получения разрешённого доступа к каждому источнику. Никакие демо-значения не будут выдаваться за реальные."));
    }
    void favorites(){reset("Избранное","Товары, которые ты сохранил");int n=0;for(Product p:products)if(isFav(p)){productCard(p);n++;}if(n==0)content.addView(note("Пока пусто","Добавляй товары в избранное с помощью сердечка."));}
    void tracking(){reset("Цены","Отслеживание стоимости выбранных товаров");content.addView(note("Уведомления","Здесь отображаются товары, для которых включено отслеживание. Уведомления о реальном снижении цены заработают после подключения сервера и накопления данных."));int n=0;for(Product p:products)if(isTracked(p)){productCard(p);n++;}if(n==0)content.addView(note("Нет отслеживаемых товаров","Открой карточку товара и нажми «Отслеживать цену»."));}
    void profile(){
        reset("Профиль","Настройки SMART BUY AI");
        content.addView(note("Тариф: Бесплатный","Премиум-экран доступен для просмотра. Подписка и платежи пока не подключены."));
        content.addView(note("Уведомления","Избранное и список отслеживания хранятся локально на этом устройстве."));
        content.addView(section("Подключение сервера поиска"));
        EditText endpoint = new EditText(this); endpoint.setSingleLine(true); endpoint.setTextColor(TEXT); endpoint.setHintTextColor(MUTED);
        endpoint.setHint("https://адрес-вашего-сервера"); endpoint.setText(prefs.getString("api_base_url", "")); endpoint.setPadding(dp(12),dp(10),dp(12),dp(10)); endpoint.setBackground(round(PANEL,12));
        content.addView(endpoint,new LinearLayout.LayoutParams(-1,dp(48)));
        TextView save = action("Сохранить адрес сервера",PURPLE); content.addView(save);
        save.setOnClickListener(v->{String value=endpoint.getText().toString().trim().replaceAll("/+$",""); if(!value.isEmpty() && !value.startsWith("https://")){Toast.makeText(this,"Нужен HTTPS-адрес сервера",Toast.LENGTH_LONG).show();return;} prefs.edit().putString("api_base_url",value).apply();Toast.makeText(this,"Адрес сохранён",Toast.LENGTH_SHORT).show();});
        content.addView(note("Поиск без API-ключей","Без сервера приложение открывает поисковые страницы магазинов. Для автоматического сбора и сравнения реальных цен нужен сервер и разрешённые публичные фиды; ключи API не обязательны, если фиды открыты."));
        TextView p=action("Открыть SMART BUY Premium",GOLD);content.addView(p);p.setOnClickListener(v->premium());
        content.addView(note("Регион: Россия","Валюта: российский рубль • Язык: русский"));
    }
    void remoteSearch(String q, String server){
        reset("Автоматический поиск", "Ищем «"+q+"» в подключённых каталогах...");
        content.addView(note("Поиск без API-ключей", "Сервер проверяет только открытые фиды, которые владелец сервера добавил с разрешением магазина."));
        new Thread(()->{
            HttpURLConnection connection=null;
            try{
                String encoded=java.net.URLEncoder.encode(q,"UTF-8");
                StringBuilder query=new StringBuilder("q=").append(encoded);
                String[] filterKeys={"brand","size","color","material","gender","season","clothing_type"};
                for(String key:filterKeys){String value=prefs.getString("clothing_"+key,"").trim();if(!value.isEmpty())query.append("&").append(key).append("=").append(java.net.URLEncoder.encode(value,"UTF-8"));}
                URL url=new URL(server+"/v1/discovery/search?"+query.toString());
                connection=(HttpURLConnection)url.openConnection(); connection.setRequestMethod("GET"); connection.setConnectTimeout(10000); connection.setReadTimeout(15000);
                int code=connection.getResponseCode(); InputStream stream=(code>=200&&code<300)?connection.getInputStream():connection.getErrorStream();
                ByteArrayOutputStream buffer=new ByteArrayOutputStream(); byte[] chunk=new byte[4096]; int n; while((n=stream.read(chunk))!=-1)buffer.write(chunk,0,n);
                if(code<200||code>=300)throw new Exception("HTTP "+code);
                JSONObject data=new JSONObject(buffer.toString("UTF-8")); JSONArray items=data.optJSONArray("items");
                runOnUiThread(()->{
                    reset("Результаты поиска", "Запрос: "+q+" • найдено: "+(items==null?0:items.length()));
                    if(items==null||items.length()==0){
                        content.addView(note("Пока нет предложений",data.optString("data_note","В подключённых открытых фидах совпадений нет.")));
                        loadMatchingCandidates(q, server);
                        return;
                    }
                    for(int i=0;i<items.length();i++){
                        JSONObject item=items.optJSONObject(i); if(item==null)continue; JSONObject product=item.optJSONObject("product"); JSONArray offers=item.optJSONArray("offers");
                        String title=product==null?"Товар":product.optString("title","Товар");
                        TextView productTitle=action("Открыть карточку  ·  "+title,PANEL2); content.addView(productTitle);
                        int remoteProductId=product==null?-1:product.optInt("id",-1);
                        if(remoteProductId>0) productTitle.setOnClickListener(v->remoteProductDetail(remoteProductId,server));
                        if(offers==null||offers.length()==0){content.addView(note("Нет предложений","Товар найден, но цена из фида не поступила."));continue;}
                        for(int j=0;j<offers.length();j++){JSONObject offer=offers.optJSONObject(j); if(offer==null)continue;
                            String shop=offer.optString("source", "Магазин"); String seller=offer.optString("seller","");
                            double price=offer.optDouble("price",0); double shipping=offer.isNull("shipping")?0:offer.optDouble("shipping",0);
                            double total=offer.has("total_price")?offer.optDouble("total_price",price+shipping):price+shipping;
                            String currency=offer.optString("currency","RUB"); String link=offer.optString("url","");
                            long age=offer.optLong("age_seconds",-1); String freshness=age<0?"Дата обновления неизвестна":age<3600?"Обновлено менее часа назад":age<86400?"Обновлено сегодня":"Устаревшее предложение — проверь цену";
                            String wholesale=offer.optBoolean("is_wholesale",false)?" • ОПТ":"";
                            content.addView(note(shop+wholesale+" • "+String.format(java.util.Locale.US,"%.0f %s",total,currency), "Цена: "+price+" "+currency+" • доставка: "+shipping+" • "+seller+"\n"+freshness+"\n"+link));
                        }
                    }
                    content.addView(note("Источник данных",data.optString("data_note","Предложения получены из подключённых фидов.")));
                    // Cross-store product identity matching is loaded separately so discovery
                    // results remain visible even if the matching endpoint is unavailable.
                    loadMatchingCandidates(q, server);
                });
            }catch(Exception ex){runOnUiThread(()->{reset("Не удалось выполнить поиск","Сервер недоступен или не настроен");content.addView(note("Проверь адрес сервера",ex.getMessage()==null?"Ошибка соединения":ex.getMessage()));});}
            finally{if(connection!=null)connection.disconnect();}
        }).start();
    }

    void loadMatchingCandidates(String q, String server){
        content.addView(section("Сравнение одинаковых товаров"));
        content.addView(note("Проверяем совпадения", "Ищем тот же товар в разных магазинах по штрихкоду, бренду и модели. Похожие названия требуют проверки."));
        new Thread(()->{
            HttpURLConnection connection=null;
            try{
                String endpoint=server+"/v1/matching/candidates?q="+java.net.URLEncoder.encode(q,"UTF-8");
                URL url=new URL(endpoint);
                connection=(HttpURLConnection)url.openConnection(); connection.setRequestMethod("GET");
                connection.setConnectTimeout(8000); connection.setReadTimeout(12000);
                int code=connection.getResponseCode();
                InputStream stream=(code>=200&&code<300)?connection.getInputStream():connection.getErrorStream();
                ByteArrayOutputStream buffer=new ByteArrayOutputStream(); byte[] chunk=new byte[4096]; int n;
                while((n=stream.read(chunk))!=-1)buffer.write(chunk,0,n);
                if(code<200||code>=300)throw new Exception("HTTP "+code);
                JSONObject data=new JSONObject(buffer.toString("UTF-8")); JSONArray candidates=data.optJSONArray("candidates");
                runOnUiThread(()->{
                    if(candidates==null||candidates.length()==0){content.addView(note("Совпадений пока нет", "Когда в подключённых каталогах появятся предложения одного товара, они будут собраны в одну сравнительную карточку."));return;}
                    content.addView(txt("Найдено кандидатов: "+candidates.length(),11,MUTED,true));
                    for(int i=0;i<candidates.length();i++){
                        JSONObject candidate=candidates.optJSONObject(i); if(candidate==null)continue;
                        JSONObject product=candidate.optJSONObject("product");
                        String title=product==null?"Товар":product.optString("title","Товар");
                        double score=candidate.optDouble("match_score",0);
                        boolean confirm=candidate.optBoolean("requires_confirmation",true);
                        String percent=String.format(java.util.Locale.US,"%.0f%%",score*100.0);
                        content.addView(section(title));
                        content.addView(note(confirm?"Похожий товар — проверь характеристики":"Высокая уверенность совпадения",
                                "Совпадение: "+percent+" • "+candidate.optString("match_reason","Сравнение характеристик")+
                                (confirm?"\nПроверь модель, размер, цвет и комплектацию перед сравнением.":"\nСовпадение по надёжным идентификаторам.")));
                        addMatchedOffers(candidate.optJSONArray("retail_offers"),"Розничные предложения");
                        JSONArray wholesale=candidate.optJSONArray("wholesale_offers");
                        if(wholesale!=null&&wholesale.length()>0)addMatchedOffers(wholesale,"Оптовые предложения (отдельно)");
                    }
                    content.addView(note("Важно",data.optString("note","Похожие названия не объединяются автоматически.")));
                });
            }catch(Exception ex){runOnUiThread(()->content.addView(note("Сопоставление временно недоступно", "Поиск предложений выполнен, но сравнение одинаковых товаров не загрузилось. Проверь сервер и повтори запрос.")));}
            finally{if(connection!=null)connection.disconnect();}
        }).start();
    }

    void addMatchedOffers(JSONArray offers, String label){
        if(offers==null||offers.length()==0)return;
        content.addView(txt(label,12,GOLD,true));
        for(int i=0;i<offers.length();i++){
            JSONObject offer=offers.optJSONObject(i); if(offer==null)continue;
            String shop=offer.optString("source","Магазин");
            double price=offer.optDouble("price",0), shipping=offer.isNull("shipping")?0:offer.optDouble("shipping",0);
            double total=offer.has("total_price")?offer.optDouble("total_price",price+shipping):price+shipping;
            String currency=offer.optString("currency","RUB"); String url=offer.optString("url","");
            String detail=String.format(java.util.Locale.US,"Цена: %.2f %s • доставка: %.2f %s",price,currency,shipping,currency);
            if(offer.has("min_order_quantity"))detail+=" • минимум: "+offer.optString("min_order_quantity");
            TextView row=action(shop+"  ·  "+String.format(java.util.Locale.US,"%.2f %s",total,currency)+"\n"+detail,PANEL2);
            content.addView(row);
            if(!url.isEmpty())row.setOnClickListener(v->{try{startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(url)));}catch(Exception e){Toast.makeText(this,"Не удалось открыть предложение",Toast.LENGTH_SHORT).show();}});
        }
    }

    void premium(){reset("SMART BUY PREMIUM","Больше возможностей для умных покупок");content.addView(note("FREE — бесплатно","Базовый поиск, карточки товаров, избранное и рекламные места."));content.addView(note("PREMIUM — без рекламы","Отключение рекламных блоков и более комфортный интерфейс."));content.addView(note("Расширенное отслеживание","Больше отслеживаемых товаров, история цен и уведомления о снижении после подключения источников."));content.addView(note("AI-помощник покупателя","Объяснение различий, сравнение характеристик и рекомендации на основе доступных данных."));content.addView(note("Реклама","В этой сборке рекламный блок является макетом. Рекламная сеть и показ объявлений не подключены."));content.addView(txt("Оплата пока недоступна: Google Play Billing и проверка подписки ещё не интегрированы. Никаких списаний не производится.",12,MUTED,false));}
    boolean isFav(Product p){return prefs.getBoolean("f_"+p.name,false);}boolean isTracked(Product p){return prefs.getBoolean("t_"+p.name,false);}
    void toggleFav(Product p){prefs.edit().putBoolean("f_"+p.name,!isFav(p)).apply();}
    void toggleTrack(Product p){prefs.edit().putBoolean("t_"+p.name,!isTracked(p)).apply();}
    TextView section(String s){TextView t=txt(s,16,TEXT,true);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.setMargins(0,dp(16),0,dp(5));t.setLayoutParams(p);return t;}
    TextView note(String title,String body){LinearLayout box=new LinearLayout(this);box.setOrientation(1);box.setPadding(dp(13),dp(12),dp(13),dp(12));GradientDrawable noteBg=round(PANEL,15);noteBg.setStroke(dp(1),0xFF26334D);box.setBackground(noteBg);LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.setMargins(0,dp(7),0,dp(7));box.setLayoutParams(lp);box.addView(txt(title,13,TEXT,true));box.addView(txt(body,11,MUTED,false));return wrapAsText(box);}
    TextView wrapAsText(LinearLayout box){ // helper used only to keep the content insertion API compact
        TextView t=txt("",1,TEXT,false); t.setVisibility(View.GONE);
        // Add the note directly to the active content container.
        content.addView(box);
        return t;
    }
    TextView action(String s,int color){TextView t=txt(s,13,Color.WHITE,true);t.setGravity(Gravity.CENTER);t.setPadding(dp(14),dp(13),dp(14),dp(13));GradientDrawable actionBg=round(color,14);actionBg.setStroke(dp(1),color==PURPLE?0xFFAA9EFF:0xFF30405E);t.setBackground(actionBg);LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.setMargins(0,dp(7),0,dp(7));t.setLayoutParams(lp);return t;}
    String money(int n){return String.format(java.util.Locale.US,"%,d ₽",n).replace(',',' ');}
    TextView txt(String s,int size,int color,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return t;}
    GradientDrawable round(int c,int r){GradientDrawable d=new GradientDrawable();d.setColor(c);d.setCornerRadius(dp(r));return d;}
    int dp(int n){return (int)(n*getResources().getDisplayMetrics().density+.5f);}
}
